import logo from './logo.svg';
import './App.css';
import bootstap from '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Navbar from './components/Navbar';

import './index.css'
function App() {
  return (
    <div className="App">
       <Navbar /> 
    </div>
    
  )
}

export default App;
